/**
 * Integration Tests for Color Palette (Dark Mode / Purple Accent Theme)
 * Tests verify theme consistency across components
 */
import { describe, it, expect } from "vitest"
import fs from "fs"
import path from "path"

describe("Color Palette - Theme Consistency", () => {
  const globalsPath = path.join(process.cwd(), "app/globals.css")

  it("should have dark mode as default (background: 210 35% 7%)", () => {
    const content = fs.readFileSync(globalsPath, "utf-8")

    // Background should be dark (low lightness value)
    expect(content).toMatch(/--color-background:\s*210\s+35%\s+7%/)
  })

  it("should have purple primary accent color (266 73% 63%)", () => {
    const content = fs.readFileSync(globalsPath, "utf-8")

    // Primary should be purple
    expect(content).toMatch(/--color-primary:\s*266\s+73%\s+63%/)
    expect(content).toMatch(/--color-accent:\s*266\s+73%\s+63%/)
  })

  it("should have consistent sidebar colors matching main theme", () => {
    const content = fs.readFileSync(globalsPath, "utf-8")

    // Sidebar should use same purple primary
    expect(content).toMatch(/--color-sidebar-primary:\s*266\s+73%\s+63%/)
    // Sidebar background should be dark
    expect(content).toMatch(/--color-sidebar:\s*210\s+30%\s+9%/)
  })

  it("should have chart colors in purple spectrum", () => {
    const content = fs.readFileSync(globalsPath, "utf-8")

    // Chart colors should be variations of purple
    expect(content).toMatch(/--color-chart-1:\s*266\s+73%\s+63%/)
    expect(content).toMatch(/--color-chart-2:\s*280\s+65%\s+60%/)
    expect(content).toMatch(/--color-chart-3:\s*250\s+70%\s+65%/)
    expect(content).toMatch(/--color-chart-4:\s*290\s+60%\s+58%/)
    expect(content).toMatch(/--color-chart-5:\s*270\s+80%\s+70%/)
  })

  it("should have proper font configuration", () => {
    const content = fs.readFileSync(globalsPath, "utf-8")

    expect(content).toMatch(/--font-sans:\s*"DM Sans"/)
    expect(content).toMatch(/--font-display:\s*"Space Grotesk"/)
  })

  it("should have widget glow effect using theme colors", () => {
    const content = fs.readFileSync(globalsPath, "utf-8")

    // Widget glow should use purple gradient
    expect(content).toContain(".widget-glow")
    expect(content).toMatch(/hsl\(280\s+73%\s+67%/)
    expect(content).toMatch(/hsl\(270\s+65%\s+75%/)
  })

  it("should have scrollbar styles using muted colors", () => {
    const content = fs.readFileSync(globalsPath, "utf-8")

    expect(content).toContain("::-webkit-scrollbar")
    expect(content).toContain("var(--color-muted")
  })

  it("should have destructive color for error states", () => {
    const content = fs.readFileSync(globalsPath, "utf-8")

    // Destructive should be red
    expect(content).toMatch(/--color-destructive:\s*0\s+65%\s+54%/)
  })

  it("should have visible border colors for widgets", () => {
    const content = fs.readFileSync(globalsPath, "utf-8")

    // Border should be visible (22% lightness mentioned in comment)
    expect(content).toMatch(/--color-border:\s*210\s+18%\s+22%/)
  })
})

describe("Color Palette - Component Consistency", () => {
  it("should apply theme colors to Card components", () => {
    // Card component should use bg-card and border-border
    const cardPath = path.join(process.cwd(), "components/ui/card.tsx")
    const content = fs.readFileSync(cardPath, "utf-8")

    expect(content).toContain("bg-card")
    expect(content).toContain("text-card-foreground")
  })

  it("should apply theme colors to Button components", () => {
    const buttonPath = path.join(process.cwd(), "components/ui/button.tsx")
    const content = fs.readFileSync(buttonPath, "utf-8")

    expect(content).toContain("bg-primary")
    expect(content).toContain("text-primary-foreground")
    expect(content).toContain("bg-destructive")
  })

  it("should apply theme to sidebar component", () => {
    const sidebarPath = path.join(process.cwd(), "components/sidebar.tsx")
    const content = fs.readFileSync(sidebarPath, "utf-8")

    // Should use sidebar-specific tokens
    expect(content).toMatch(/bg-sidebar|sidebar/)
  })
})
