import type React from "react"
/**
 * Integration Tests for Custom Layout Engine (Drag-and-Drop Grid System)
 * Tests verify that drag operations actually update grid coordinates in state
 */
import { describe, it, expect, beforeEach } from "vitest"
import { renderHook, act } from "@testing-library/react"
import { AppDataProvider, useAppData } from "@/contexts/app-data-context"
import { isValidPosition, findAvailablePosition, compactWidgets } from "@/lib/grid-utils"
import type { DashboardWidget, TrackingPageSection } from "@/types"

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {}
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value
    },
    removeItem: (key: string) => {
      delete store[key]
    },
    clear: () => {
      store = {}
    },
  }
})()

Object.defineProperty(window, "localStorage", { value: localStorageMock })

const wrapper = ({ children }: { children: React.ReactNode }) => <AppDataProvider>{children}</AppDataProvider>

describe("Custom Layout Engine - Grid Utilities", () => {
  const GRID_COLS = 4
  const GRID_ROWS = 6

  describe("isValidPosition", () => {
    const baseWidgets: TrackingPageSection[] = [
      { id: "widget-1", size: { width: 2, height: 2 }, position: { x: 0, y: 0 }, visible: true },
      { id: "widget-2", size: { width: 1, height: 1 }, position: { x: 2, y: 0 }, visible: true },
    ]

    it("should return false when position is outside grid boundaries", () => {
      expect(isValidPosition([], -1, 0, 1, 1)).toBe(false)
      expect(isValidPosition([], 0, -1, 1, 1)).toBe(false)
      expect(isValidPosition([], GRID_COLS, 0, 1, 1)).toBe(false)
      expect(isValidPosition([], 0, GRID_ROWS, 1, 1)).toBe(false)
    })

    it("should return false when widget extends beyond grid boundaries", () => {
      expect(isValidPosition([], GRID_COLS - 1, 0, 2, 1)).toBe(false) // Extends right
      expect(isValidPosition([], 0, GRID_ROWS - 1, 1, 2)).toBe(false) // Extends bottom
    })

    it("should return false when position overlaps existing widget", () => {
      // Try to place at (1, 1) which overlaps with widget-1 (2x2 at 0,0)
      expect(isValidPosition(baseWidgets, 1, 1, 1, 1)).toBe(false)
      // Try to place at (2, 0) which overlaps with widget-2
      expect(isValidPosition(baseWidgets, 2, 0, 1, 1)).toBe(false)
    })

    it("should return true when position is valid and empty", () => {
      // Position (3, 0) is empty
      expect(isValidPosition(baseWidgets, 3, 0, 1, 1)).toBe(true)
      // Position (0, 2) is below widget-1
      expect(isValidPosition(baseWidgets, 0, 2, 2, 2)).toBe(true)
    })

    it("should allow placing at current position when excludeId matches", () => {
      // widget-1 is at (0,0) - should be valid when excluding itself
      expect(isValidPosition(baseWidgets, 0, 0, 2, 2, "widget-1")).toBe(true)
    })
  })

  describe("findAvailablePosition", () => {
    it("should find first available position scanning left-to-right, top-to-bottom", () => {
      const widgets: TrackingPageSection[] = [
        { id: "w1", size: { width: 1, height: 1 }, position: { x: 0, y: 0 }, visible: true },
      ]

      const position = findAvailablePosition(widgets, 1, 1)
      expect(position).toEqual({ x: 1, y: 0 }) // Next to existing widget
    })

    it("should return null when no position is available", () => {
      // Fill entire grid with one large widget
      const widgets: TrackingPageSection[] = [
        { id: "full", size: { width: GRID_COLS, height: GRID_ROWS }, position: { x: 0, y: 0 }, visible: true },
      ]

      const position = findAvailablePosition(widgets, 1, 1)
      expect(position).toBeNull()
    })

    it("should find position that fits widget dimensions", () => {
      const widgets: TrackingPageSection[] = [
        { id: "w1", size: { width: 3, height: 1 }, position: { x: 0, y: 0 }, visible: true },
      ]

      // A 2x2 widget won't fit at (3, 0) - only 1 column left
      // Should find position at (0, 1) where there's enough room
      const position = findAvailablePosition(widgets, 2, 2)
      expect(position).toEqual({ x: 0, y: 1 })
    })
  })

  describe("compactWidgets", () => {
    it("should move widgets to fill empty spaces (top-left priority)", () => {
      const widgets: TrackingPageSection[] = [
        { id: "w1", size: { width: 1, height: 1 }, position: { x: 2, y: 2 }, visible: true }, // Has gap
        { id: "w2", size: { width: 1, height: 1 }, position: { x: 3, y: 3 }, visible: true }, // Has gap
      ]

      const compacted = compactWidgets(widgets)

      // Should compact to top-left
      expect(compacted.find((w) => w.id === "w1")?.position).toEqual({ x: 0, y: 0 })
      expect(compacted.find((w) => w.id === "w2")?.position).toEqual({ x: 1, y: 0 })
    })

    it("should maintain relative order when compacting", () => {
      const widgets: TrackingPageSection[] = [
        { id: "w2", size: { width: 1, height: 1 }, position: { x: 0, y: 1 }, visible: true },
        { id: "w1", size: { width: 1, height: 1 }, position: { x: 0, y: 0 }, visible: true },
      ]

      const compacted = compactWidgets(widgets)

      // w1 (at y:0) should come first after sorting
      expect(compacted[0].id).toBe("w1")
    })
  })
})

describe("Custom Layout Engine - Dashboard State Management", () => {
  beforeEach(() => {
    localStorageMock.clear()
  })

  describe("updateWidgetPosition", () => {
    it("should update widget grid coordinates in state", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      const exerciseWidget = result.current.dashboardLayout.widgets.find((w) => w.id === "exercise")
      const originalPosition = { ...exerciseWidget?.position }

      act(() => {
        result.current.updateWidgetPosition("exercise", 5, 3)
      })

      const updatedWidget = result.current.dashboardLayout.widgets.find((w) => w.id === "exercise")
      expect(updatedWidget?.position.x).toBe(5)
      expect(updatedWidget?.position.y).toBe(3)
      expect(updatedWidget?.position).not.toEqual(originalPosition)
    })

    it("should update dashboardLayout.updatedAt timestamp", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      const originalUpdatedAt = result.current.dashboardLayout.updatedAt

      await act(async () => {
        await new Promise((r) => setTimeout(r, 50))
      })

      act(() => {
        result.current.updateWidgetPosition("exercise", 1, 1)
      })

      expect(new Date(result.current.dashboardLayout.updatedAt).getTime()).toBeGreaterThanOrEqual(
        new Date(originalUpdatedAt).getTime(),
      )
    })
  })

  describe("updateDashboardLayout", () => {
    it("should replace entire widgets array maintaining structure", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      const newWidgets: DashboardWidget[] = [
        { id: "exercise", type: "builtin", size: { width: 2, height: 2 }, position: { x: 0, y: 0 }, visible: true },
        { id: "diet", type: "builtin", size: { width: 2, height: 2 }, position: { x: 2, y: 0 }, visible: true },
      ]

      act(() => {
        result.current.updateDashboardLayout(newWidgets)
      })

      expect(result.current.dashboardLayout.widgets.length).toBe(2)
      expect(result.current.dashboardLayout.widgets[0].position).toEqual({ x: 0, y: 0 })
      expect(result.current.dashboardLayout.widgets[1].position).toEqual({ x: 2, y: 0 })
    })

    it("should correctly reorder widgets after drag operation", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      // Simulate drag: move first widget to different position
      const originalWidgets = [...result.current.dashboardLayout.widgets]
      const reorderedWidgets = originalWidgets.map((w) => {
        if (w.id === "exercise") {
          return { ...w, position: { x: 8, y: 6 } }
        }
        return w
      })

      act(() => {
        result.current.updateDashboardLayout(reorderedWidgets)
      })

      const exerciseWidget = result.current.dashboardLayout.widgets.find((w) => w.id === "exercise")
      expect(exerciseWidget?.position).toEqual({ x: 8, y: 6 })
    })
  })

  describe("toggleWidgetVisibility", () => {
    it("should toggle visible property of widget", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      const initialVisibility = result.current.dashboardLayout.widgets.find((w) => w.id === "exercise")?.visible

      act(() => {
        result.current.toggleWidgetVisibility("exercise")
      })

      const newVisibility = result.current.dashboardLayout.widgets.find((w) => w.id === "exercise")?.visible
      expect(newVisibility).toBe(!initialVisibility)
    })
  })

  describe("Tracking Page Layouts", () => {
    it("should store and retrieve per-page layout configurations", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      const exerciseLayout = {
        sections: [
          { id: "workout", size: { width: 3, height: 3 }, position: { x: 0, y: 0 }, visible: true },
          { id: "stats", size: { width: 2, height: 2 }, position: { x: 3, y: 0 }, visible: true },
        ],
        gridColumns: 10,
        updatedAt: new Date(),
      }

      act(() => {
        result.current.updateTrackingPageLayout("exercise", exerciseLayout)
      })

      const retrieved = result.current.getTrackingPageLayout("exercise")
      expect(retrieved?.sections.length).toBe(2)
      expect(retrieved?.sections[0].id).toBe("workout")
      expect(retrieved?.sections[0].position).toEqual({ x: 0, y: 0 })
    })

    it("should return undefined for non-existent page layouts", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      const layout = result.current.getTrackingPageLayout("non-existent-page")
      expect(layout).toBeUndefined()
    })
  })

  describe("Layout Persistence", () => {
    it("should persist dashboard layout to localStorage", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      act(() => {
        result.current.updateWidgetPosition("exercise", 7, 5)
      })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 50))
      })

      const stored = localStorage.getItem("habit-tracker-dashboard-layout")
      expect(stored).not.toBeNull()

      const parsed = JSON.parse(stored!)
      const exerciseWidget = parsed.widgets.find((w: DashboardWidget) => w.id === "exercise")
      expect(exerciseWidget.position).toEqual({ x: 7, y: 5 })
    })
  })
})
