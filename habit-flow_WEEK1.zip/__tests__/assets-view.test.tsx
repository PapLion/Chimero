import type React from "react"
/**
 * Integration Tests for Assets View
 * Tests verify asset CRUD operations and state management
 */
import { describe, it, expect, beforeEach } from "vitest"
import { renderHook, act } from "@testing-library/react"
import { AppDataProvider, useAppData } from "@/contexts/app-data-context"
import { getFileExtension, isValidImageUrl } from "@/lib/asset-utils"
import type { Asset } from "@/types"

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {}
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value
    },
    removeItem: (key: string) => {
      delete store[key]
    },
    clear: () => {
      store = {}
    },
  }
})()

Object.defineProperty(window, "localStorage", { value: localStorageMock })

const wrapper = ({ children }: { children: React.ReactNode }) => <AppDataProvider>{children}</AppDataProvider>

describe("Assets View - Asset Utilities", () => {
  describe("getFileExtension", () => {
    it("should extract extension from filename", () => {
      expect(getFileExtension("image.png")).toBe("png")
      expect(getFileExtension("photo.jpg")).toBe("jpg")
      expect(getFileExtension("icon.svg")).toBe("svg")
      expect(getFileExtension("animation.gif")).toBe("gif")
      expect(getFileExtension("modern.webp")).toBe("webp")
    })

    it("should normalize jpeg to jpg", () => {
      expect(getFileExtension("photo.jpeg")).toBe("jpg")
    })

    it("should fallback to MIME type when extension is unknown", () => {
      expect(getFileExtension("file.unknown", "image/png")).toBe("png")
      expect(getFileExtension("file", "image/jpeg")).toBe("jpg")
      expect(getFileExtension("file", "image/svg+xml")).toBe("svg")
    })

    it("should return 'other' when no valid extension found", () => {
      expect(getFileExtension("file.xyz")).toBe("other")
      expect(getFileExtension("file", "application/octet-stream")).toBe("other")
    })
  })

  describe("isValidImageUrl", () => {
    it("should validate base64 image strings", () => {
      expect(isValidImageUrl("data:image/png;base64,iVBORw0KGgo=")).toBe(true)
      expect(isValidImageUrl("data:image/jpeg;base64,/9j/4AAQ=")).toBe(true)
      expect(isValidImageUrl("data:image/svg+xml;base64,PHN2Zz4=")).toBe(true)
    })

    it("should validate regular URLs", () => {
      expect(isValidImageUrl("https://example.com/image.png")).toBe(true)
      expect(isValidImageUrl("http://localhost:3000/image.jpg")).toBe(true)
    })

    it("should reject invalid strings", () => {
      expect(isValidImageUrl("not-a-url")).toBe(false)
      expect(isValidImageUrl("")).toBe(false)
    })
  })
})

describe("Assets View - State Management", () => {
  beforeEach(() => {
    localStorageMock.clear()
  })

  describe("addAsset", () => {
    it("should add new asset with auto-generated ID and timestamps", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      const initialCount = result.current.assets.length

      act(() => {
        result.current.addAsset({
          name: "Game Cover",
          category: "games",
          url: "data:image/png;base64,test123",
          type: "png",
          size: 1024,
        })
      })

      expect(result.current.assets.length).toBe(initialCount + 1)

      const newAsset = result.current.assets[result.current.assets.length - 1]
      expect(newAsset.name).toBe("Game Cover")
      expect(newAsset.category).toBe("games")
      expect(newAsset.id).toBeDefined()
      expect(newAsset.uploadedAt).toBeDefined()
      expect(newAsset.updatedAt).toBeDefined()
    })

    it("should correctly categorize assets", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      const categories = ["games", "books", "tv", "apps", "other"] as const

      for (const category of categories) {
        act(() => {
          result.current.addAsset({
            name: `Test ${category}`,
            category,
            url: "data:image/png;base64,test",
            type: "png",
          })
        })
      }

      for (const category of categories) {
        const asset = result.current.assets.find((a) => a.name === `Test ${category}`)
        expect(asset?.category).toBe(category)
      }
    })
  })

  describe("updateAsset", () => {
    it("should update asset properties and refresh updatedAt", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      act(() => {
        result.current.addAsset({
          name: "Original",
          category: "other",
          url: "data:image/png;base64,original",
          type: "png",
        })
      })

      const assetId = result.current.assets[result.current.assets.length - 1].id
      const originalUpdatedAt = result.current.assets.find((a) => a.id === assetId)?.updatedAt

      await act(async () => {
        await new Promise((r) => setTimeout(r, 50))
      })

      act(() => {
        result.current.updateAsset(assetId, {
          name: "Updated Name",
          category: "games",
        })
      })

      const updatedAsset = result.current.assets.find((a) => a.id === assetId)
      expect(updatedAsset?.name).toBe("Updated Name")
      expect(updatedAsset?.category).toBe("games")
      expect(new Date(updatedAsset?.updatedAt!).getTime()).toBeGreaterThanOrEqual(
        new Date(originalUpdatedAt!).getTime(),
      )
    })

    it("should allow replacing asset URL (image replacement)", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      act(() => {
        result.current.addAsset({
          name: "Replace Test",
          category: "other",
          url: "data:image/png;base64,original",
          type: "png",
        })
      })

      const assetId = result.current.assets[result.current.assets.length - 1].id

      act(() => {
        result.current.updateAsset(assetId, {
          url: "data:image/jpeg;base64,newimage",
        })
      })

      const updatedAsset = result.current.assets.find((a) => a.id === assetId)
      expect(updatedAsset?.url).toBe("data:image/jpeg;base64,newimage")
    })
  })

  describe("deleteAsset", () => {
    it("should remove asset from state", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      act(() => {
        result.current.addAsset({
          name: "To Delete",
          category: "other",
          url: "data:image/png;base64,delete",
          type: "png",
        })
      })

      const assetId = result.current.assets[result.current.assets.length - 1].id
      const countBefore = result.current.assets.length

      act(() => {
        result.current.deleteAsset(assetId)
      })

      expect(result.current.assets.length).toBe(countBefore - 1)
      expect(result.current.assets.find((a) => a.id === assetId)).toBeUndefined()
    })

    it("should cascade delete asset references from activity logs", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      // Add an asset
      act(() => {
        result.current.addAsset({
          name: "Cascade Test",
          category: "games",
          url: "data:image/png;base64,cascade",
          type: "png",
        })
      })

      const assetId = result.current.assets[result.current.assets.length - 1].id

      // Add activity log referencing this asset
      act(() => {
        result.current.addActivityLog({
          type: "game",
          timestamp: new Date(),
          data: {
            playTime: 120,
            unit: "minutes",
            lastPlayedGame: "Test Game",
            coverAssetId: assetId,
          },
        })
      })

      // Delete asset - should cascade
      act(() => {
        result.current.deleteAsset(assetId)
      })

      // Verify asset reference removed from activity log
      const gameLog = result.current.activityLogs.find((l) => l.type === "game")
      expect((gameLog?.data as any).coverAssetId).toBeUndefined()
    })
  })

  describe("Asset Persistence", () => {
    it("should persist assets to localStorage", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      act(() => {
        result.current.addAsset({
          name: "Persist Test",
          category: "books",
          url: "data:image/png;base64,persist",
          type: "png",
        })
      })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 50))
      })

      const stored = localStorage.getItem("habit-tracker-assets")
      expect(stored).not.toBeNull()

      const parsed = JSON.parse(stored!)
      expect(parsed.some((a: Asset) => a.name === "Persist Test")).toBe(true)
    })
  })
})
