import type React from "react"
/**
 * Integration Tests for Custom Tracker System
 * Tests verify logic and state changes, not just rendering
 */
import { describe, it, expect, beforeEach, vi } from "vitest"
import { renderHook, act } from "@testing-library/react"
import { AppDataProvider, useAppData } from "@/contexts/app-data-context"
import type { CustomTrackerConfig } from "@/types"

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {}
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value
    },
    removeItem: (key: string) => {
      delete store[key]
    },
    clear: () => {
      store = {}
    },
  }
})()

Object.defineProperty(window, "localStorage", { value: localStorageMock })

const wrapper = ({ children }: { children: React.ReactNode }) => <AppDataProvider>{children}</AppDataProvider>

describe("Custom Tracker System", () => {
  beforeEach(() => {
    localStorageMock.clear()
    vi.clearAllMocks()
  })

  describe("addCustomTracker", () => {
    it("should add a new tracker with auto-generated ID and timestamps", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      // Wait for hydration
      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      const initialCount = result.current.customTrackers.length

      act(() => {
        result.current.addCustomTracker({
          name: "Water Intake",
          description: "Track daily water consumption",
          icon: "Droplet",
          color: "#3B82F6",
          fields: [{ id: "glasses", label: "Glasses", type: "number", required: true }],
          showOnDashboard: true,
          widgetSize: "small",
          hasGoal: true,
          goalField: "glasses",
          goalValue: 8,
          goalType: "daily",
          chartType: "bar",
        })
      })

      expect(result.current.customTrackers.length).toBe(initialCount + 1)

      const newTracker = result.current.customTrackers[result.current.customTrackers.length - 1]
      expect(newTracker.name).toBe("Water Intake")
      expect(newTracker.id).toMatch(/^custom-\d+$/)
      expect(newTracker.createdAt).toBeDefined()
      expect(newTracker.updatedAt).toBeDefined()
    })

    it("should add tracker widget to dashboard when showOnDashboard is true", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      const initialWidgetCount = result.current.dashboardLayout.widgets.length

      act(() => {
        result.current.addCustomTracker({
          name: "Test Tracker",
          fields: [{ id: "value", label: "Value", type: "number" }],
          showOnDashboard: true,
          chartType: "line",
        })
      })

      const newTracker = result.current.customTrackers[result.current.customTrackers.length - 1]
      const dashboardWidget = result.current.dashboardLayout.widgets.find((w) => w.id === newTracker.id)

      expect(result.current.dashboardLayout.widgets.length).toBe(initialWidgetCount + 1)
      expect(dashboardWidget).toBeDefined()
      expect(dashboardWidget?.type).toBe("custom")
      expect(dashboardWidget?.visible).toBe(true)
    })
  })

  describe("updateCustomTracker", () => {
    it("should update tracker properties and refresh updatedAt timestamp", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      act(() => {
        result.current.addCustomTracker({
          name: "Original Name",
          fields: [{ id: "value", label: "Value", type: "number" }],
          showOnDashboard: false,
          chartType: "line",
        })
      })

      const trackerId = result.current.customTrackers[result.current.customTrackers.length - 1].id
      const originalUpdatedAt = result.current.customTrackers.find((t) => t.id === trackerId)?.updatedAt

      // Small delay to ensure timestamp difference
      await act(async () => {
        await new Promise((r) => setTimeout(r, 50))
      })

      act(() => {
        result.current.updateCustomTracker(trackerId, { name: "Updated Name", color: "#FF0000" })
      })

      const updatedTracker = result.current.customTrackers.find((t) => t.id === trackerId)
      expect(updatedTracker?.name).toBe("Updated Name")
      expect(updatedTracker?.color).toBe("#FF0000")
      expect(new Date(updatedTracker?.updatedAt!).getTime()).toBeGreaterThanOrEqual(
        new Date(originalUpdatedAt!).getTime(),
      )
    })

    it("should add/remove dashboard widget when toggling showOnDashboard", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      act(() => {
        result.current.addCustomTracker({
          name: "Toggle Test",
          fields: [{ id: "value", label: "Value", type: "number" }],
          showOnDashboard: false,
          chartType: "line",
        })
      })

      const trackerId = result.current.customTrackers[result.current.customTrackers.length - 1].id

      // Initially not on dashboard
      expect(result.current.dashboardLayout.widgets.find((w) => w.id === trackerId)).toBeUndefined()

      // Toggle ON
      act(() => {
        result.current.updateCustomTracker(trackerId, { showOnDashboard: true })
      })
      expect(result.current.dashboardLayout.widgets.find((w) => w.id === trackerId)).toBeDefined()

      // Toggle OFF
      act(() => {
        result.current.updateCustomTracker(trackerId, { showOnDashboard: false })
      })
      expect(result.current.dashboardLayout.widgets.find((w) => w.id === trackerId)).toBeUndefined()
    })
  })

  describe("deleteCustomTracker", () => {
    it("should remove tracker, all its entries, and dashboard widget", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      // Add tracker
      act(() => {
        result.current.addCustomTracker({
          name: "To Delete",
          fields: [{ id: "value", label: "Value", type: "number" }],
          showOnDashboard: true,
          chartType: "line",
        })
      })

      const trackerId = result.current.customTrackers[result.current.customTrackers.length - 1].id

      // Add entries for this tracker
      act(() => {
        result.current.addCustomTrackerEntry({ trackerId, data: { value: 10 } })
        result.current.addCustomTrackerEntry({ trackerId, data: { value: 20 } })
      })

      expect(result.current.getTrackerEntries(trackerId).length).toBe(2)
      expect(result.current.dashboardLayout.widgets.find((w) => w.id === trackerId)).toBeDefined()

      // Delete tracker
      act(() => {
        result.current.deleteCustomTracker(trackerId)
      })

      expect(result.current.customTrackers.find((t) => t.id === trackerId)).toBeUndefined()
      expect(result.current.getTrackerEntries(trackerId).length).toBe(0)
      expect(result.current.dashboardLayout.widgets.find((w) => w.id === trackerId)).toBeUndefined()
    })
  })

  describe("Custom Tracker Entries", () => {
    it("should add entry with auto-generated ID and timestamp", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      act(() => {
        result.current.addCustomTracker({
          name: "Entry Test",
          fields: [{ id: "score", label: "Score", type: "scale", min: 1, max: 10 }],
          showOnDashboard: false,
          chartType: "line",
        })
      })

      const trackerId = result.current.customTrackers[result.current.customTrackers.length - 1].id

      act(() => {
        result.current.addCustomTrackerEntry({
          trackerId,
          data: { score: 7 },
          notes: "Good day",
        })
      })

      const entries = result.current.getTrackerEntries(trackerId)
      expect(entries.length).toBe(1)
      expect(entries[0].data.score).toBe(7)
      expect(entries[0].notes).toBe("Good day")
      expect(entries[0].id).toBeDefined()
      expect(entries[0].timestamp).toBeDefined()
    })

    it("should filter entries by trackerId correctly", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      // Create two trackers
      act(() => {
        result.current.addCustomTracker({
          name: "Tracker A",
          fields: [{ id: "value", label: "Value", type: "number" }],
          showOnDashboard: false,
          chartType: "line",
        })
        result.current.addCustomTracker({
          name: "Tracker B",
          fields: [{ id: "value", label: "Value", type: "number" }],
          showOnDashboard: false,
          chartType: "line",
        })
      })

      const trackerAId = result.current.customTrackers[result.current.customTrackers.length - 2].id
      const trackerBId = result.current.customTrackers[result.current.customTrackers.length - 1].id

      // Add entries to both
      act(() => {
        result.current.addCustomTrackerEntry({ trackerId: trackerAId, data: { value: 1 } })
        result.current.addCustomTrackerEntry({ trackerId: trackerAId, data: { value: 2 } })
        result.current.addCustomTrackerEntry({ trackerId: trackerBId, data: { value: 100 } })
      })

      expect(result.current.getTrackerEntries(trackerAId).length).toBe(2)
      expect(result.current.getTrackerEntries(trackerBId).length).toBe(1)
      expect(result.current.getTrackerEntries(trackerAId)[0].data.value).toBe(1)
      expect(result.current.getTrackerEntries(trackerBId)[0].data.value).toBe(100)
    })
  })

  describe("localStorage Persistence", () => {
    it("should persist custom trackers to localStorage on state change", async () => {
      const { result } = renderHook(() => useAppData(), { wrapper })

      await act(async () => {
        await new Promise((r) => setTimeout(r, 100))
      })

      act(() => {
        result.current.addCustomTracker({
          name: "Persistence Test",
          fields: [{ id: "value", label: "Value", type: "number" }],
          showOnDashboard: false,
          chartType: "line",
        })
      })

      // Wait for effect to run
      await act(async () => {
        await new Promise((r) => setTimeout(r, 50))
      })

      const stored = localStorage.getItem("habit-tracker-custom-trackers")
      expect(stored).not.toBeNull()

      const parsed = JSON.parse(stored!)
      expect(parsed.some((t: CustomTrackerConfig) => t.name === "Persistence Test")).toBe(true)
    })
  })
})
