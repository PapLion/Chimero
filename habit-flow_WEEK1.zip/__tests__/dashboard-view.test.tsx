import type React from "react"
/**
 * Integration Tests for General Dashboard View
 * Tests verify dashboard renders and manages widgets correctly
 */
import { describe, it, expect, beforeEach } from "vitest"
import { renderHook, act } from "@testing-library/react"
import { AppDataProvider, useAppData } from "@/contexts/app-data-context"

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {}
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value
    },
    removeItem: (key: string) => {
      delete store[key]
    },
    clear: () => {
      store = {}
    },
  }
})()

Object.defineProperty(window, "localStorage", { value: localStorageMock })

const wrapper = ({ children }: { children: React.ReactNode }) => <AppDataProvider>{children}</AppDataProvider>

describe("Dashboard View - Widget Management", () => {
  beforeEach(() => {
    localStorageMock.clear()
  })

  it("should have default dashboard layout on first load", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    expect(result.current.dashboardLayout).toBeDefined()
    expect(result.current.dashboardLayout.widgets.length).toBeGreaterThan(0)
    expect(result.current.dashboardLayout.gridColumns).toBe(4)
  })

  it("should filter visible widgets correctly", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    const allWidgets = result.current.dashboardLayout.widgets
    const visibleWidgets = allWidgets.filter((w) => w.visible)

    // Initially all should be visible
    expect(visibleWidgets.length).toBe(allWidgets.length)

    // Hide one
    act(() => {
      result.current.toggleWidgetVisibility("exercise")
    })

    const newVisibleWidgets = result.current.dashboardLayout.widgets.filter((w) => w.visible)
    expect(newVisibleWidgets.length).toBe(allWidgets.length - 1)
  })

  it("should integrate custom trackers into dashboard layout", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    const initialWidgetCount = result.current.dashboardLayout.widgets.length

    // Add custom tracker with showOnDashboard: true
    act(() => {
      result.current.addCustomTracker({
        name: "Custom Dashboard Widget",
        fields: [{ id: "value", label: "Value", type: "number" }],
        showOnDashboard: true,
        chartType: "line",
      })
    })

    expect(result.current.dashboardLayout.widgets.length).toBe(initialWidgetCount + 1)

    // Find the custom widget
    const customWidget = result.current.dashboardLayout.widgets.find((w) => w.type === "custom")
    expect(customWidget).toBeDefined()
    expect(customWidget?.visible).toBe(true)
  })

  it("should correctly distinguish between builtin and custom widgets", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    // Add custom tracker
    act(() => {
      result.current.addCustomTracker({
        name: "Type Test",
        fields: [{ id: "value", label: "Value", type: "number" }],
        showOnDashboard: true,
        chartType: "line",
      })
    })

    const builtinWidgets = result.current.dashboardLayout.widgets.filter((w) => w.type === "builtin")
    const customWidgets = result.current.dashboardLayout.widgets.filter((w) => w.type === "custom")

    expect(builtinWidgets.length).toBe(10) // All default trackers
    expect(customWidgets.length).toBeGreaterThanOrEqual(1)

    // Verify builtin IDs
    const builtinIds = builtinWidgets.map((w) => w.id)
    expect(builtinIds).toContain("exercise")
    expect(builtinIds).toContain("diet")
    expect(builtinIds).toContain("weight")
  })

  it("should update layout timestamp on any change", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    const originalTimestamp = new Date(result.current.dashboardLayout.updatedAt).getTime()

    await act(async () => {
      await new Promise((r) => setTimeout(r, 50))
    })

    act(() => {
      result.current.updateWidgetPosition("exercise", 3, 3)
    })

    const newTimestamp = new Date(result.current.dashboardLayout.updatedAt).getTime()
    expect(newTimestamp).toBeGreaterThanOrEqual(originalTimestamp)
  })
})

describe("Dashboard View - Custom Tracker Integration", () => {
  beforeEach(() => {
    localStorageMock.clear()
  })

  it("should remove custom tracker widget when tracker is deleted", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    // Add custom tracker
    act(() => {
      result.current.addCustomTracker({
        name: "Delete Test",
        fields: [{ id: "value", label: "Value", type: "number" }],
        showOnDashboard: true,
        chartType: "line",
      })
    })

    const trackerId = result.current.customTrackers[result.current.customTrackers.length - 1].id

    // Verify widget exists
    expect(result.current.dashboardLayout.widgets.find((w) => w.id === trackerId)).toBeDefined()

    // Delete tracker
    act(() => {
      result.current.deleteCustomTracker(trackerId)
    })

    // Verify widget removed
    expect(result.current.dashboardLayout.widgets.find((w) => w.id === trackerId)).toBeUndefined()
  })

  it("should toggle custom tracker dashboard visibility via updateCustomTracker", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    // Add tracker NOT on dashboard
    act(() => {
      result.current.addCustomTracker({
        name: "Toggle Test",
        fields: [{ id: "value", label: "Value", type: "number" }],
        showOnDashboard: false,
        chartType: "line",
      })
    })

    const trackerId = result.current.customTrackers[result.current.customTrackers.length - 1].id

    // Not on dashboard
    expect(result.current.dashboardLayout.widgets.find((w) => w.id === trackerId)).toBeUndefined()

    // Add to dashboard
    act(() => {
      result.current.updateCustomTracker(trackerId, { showOnDashboard: true })
    })

    expect(result.current.dashboardLayout.widgets.find((w) => w.id === trackerId)).toBeDefined()

    // Remove from dashboard
    act(() => {
      result.current.updateCustomTracker(trackerId, { showOnDashboard: false })
    })

    expect(result.current.dashboardLayout.widgets.find((w) => w.id === trackerId)).toBeUndefined()
  })
})
