import type React from "react"
/**
 * Integration Tests for Default Trackers (Mocked Data)
 * Tests verify all built-in tracker types render correct mock data
 */
import { describe, it, expect, beforeEach } from "vitest"
import { renderHook, act } from "@testing-library/react"
import { AppDataProvider, useAppData } from "@/contexts/app-data-context"

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {}
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value
    },
    removeItem: (key: string) => {
      delete store[key]
    },
    clear: () => {
      store = {}
    },
  }
})()

Object.defineProperty(window, "localStorage", { value: localStorageMock })

const wrapper = ({ children }: { children: React.ReactNode }) => <AppDataProvider>{children}</AppDataProvider>

const BUILTIN_TRACKER_IDS = ["exercise", "diet", "weight", "tasks", "mood", "social", "media", "tv", "books", "gaming"]

describe("Default Trackers - Dashboard Layout", () => {
  beforeEach(() => {
    localStorageMock.clear()
  })

  it("should have all 10 built-in tracker widgets in default layout", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    const builtinWidgets = result.current.dashboardLayout.widgets.filter((w) => w.type === "builtin")

    expect(builtinWidgets.length).toBe(10)

    for (const id of BUILTIN_TRACKER_IDS) {
      expect(builtinWidgets.some((w) => w.id === id)).toBe(true)
    }
  })

  it("should have all built-in trackers visible by default", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    for (const id of BUILTIN_TRACKER_IDS) {
      const widget = result.current.dashboardLayout.widgets.find((w) => w.id === id)
      expect(widget?.visible).toBe(true)
    }
  })

  it("should have valid grid positions for all default widgets", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    for (const widget of result.current.dashboardLayout.widgets) {
      expect(widget.position.x).toBeGreaterThanOrEqual(0)
      expect(widget.position.y).toBeGreaterThanOrEqual(0)
      expect(widget.size.width).toBeGreaterThan(0)
      expect(widget.size.height).toBeGreaterThan(0)
    }
  })

  it("should support toggling visibility of built-in trackers", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    // Toggle exercise off
    act(() => {
      result.current.toggleWidgetVisibility("exercise")
    })

    expect(result.current.dashboardLayout.widgets.find((w) => w.id === "exercise")?.visible).toBe(false)

    // Toggle back on
    act(() => {
      result.current.toggleWidgetVisibility("exercise")
    })

    expect(result.current.dashboardLayout.widgets.find((w) => w.id === "exercise")?.visible).toBe(true)
  })

  it("should check tracker visibility correctly with isTrackerVisibleOnDashboard", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    // Initially visible
    expect(result.current.isTrackerVisibleOnDashboard("exercise")).toBe(true)

    // Toggle off
    act(() => {
      result.current.toggleWidgetVisibility("exercise")
    })

    expect(result.current.isTrackerVisibleOnDashboard("exercise")).toBe(false)
  })
})

describe("Default Trackers - Activity Logging", () => {
  beforeEach(() => {
    localStorageMock.clear()
  })

  it("should add activity log for each tracker type", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    // Add exercise log
    act(() => {
      result.current.addActivityLog({
        type: "exercise",
        timestamp: new Date(),
        data: {
          hoursCompleted: 1.5,
          goalHours: 2,
          percentage: 75,
          unit: "hours",
        },
      })
    })

    // Add diet log
    act(() => {
      result.current.addActivityLog({
        type: "diet",
        timestamp: new Date(),
        data: {
          status: "on-track",
          macros: { protein: 120, carbs: 200, fats: 60 },
        },
      })
    })

    // Add mood log
    act(() => {
      result.current.addActivityLog({
        type: "mood",
        timestamp: new Date(),
        data: {
          currentRating: 8,
          dailyAverage: 7,
          dailyMin: 5,
          dailyMax: 9,
          entriesCount: 3,
          history: [],
        },
      })
    })

    expect(result.current.activityLogs.filter((l) => l.type === "exercise").length).toBe(1)
    expect(result.current.activityLogs.filter((l) => l.type === "diet").length).toBe(1)
    expect(result.current.activityLogs.filter((l) => l.type === "mood").length).toBe(1)
  })

  it("should update existing activity log", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    act(() => {
      result.current.addActivityLog({
        type: "weight",
        timestamp: new Date(),
        data: {
          current: 75,
          unit: "kg",
          trend: -0.5,
          trendDirection: "down",
          goal: 70,
          history: [],
        },
      })
    })

    const logId = result.current.activityLogs[result.current.activityLogs.length - 1].id

    act(() => {
      result.current.updateActivityLog(logId, {
        data: {
          current: 74.5,
          unit: "kg",
          trend: -1,
          trendDirection: "down",
          goal: 70,
          history: [],
        },
      })
    })

    const updatedLog = result.current.activityLogs.find((l) => l.id === logId)
    expect((updatedLog?.data as any).current).toBe(74.5)
  })

  it("should delete activity log", async () => {
    const { result } = renderHook(() => useAppData(), { wrapper })

    await act(async () => {
      await new Promise((r) => setTimeout(r, 100))
    })

    act(() => {
      result.current.addActivityLog({
        type: "tasks",
        timestamp: new Date(),
        data: {
          completed: 5,
          total: 10,
          remaining: 5,
          percentage: 50,
        },
      })
    })

    const logId = result.current.activityLogs[result.current.activityLogs.length - 1].id
    const countBefore = result.current.activityLogs.length

    act(() => {
      result.current.deleteActivityLog(logId)
    })

    expect(result.current.activityLogs.length).toBe(countBefore - 1)
    expect(result.current.activityLogs.find((l) => l.id === logId)).toBeUndefined()
  })
})
